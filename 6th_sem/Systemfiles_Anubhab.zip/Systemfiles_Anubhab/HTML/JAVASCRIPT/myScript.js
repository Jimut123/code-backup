function myFunction() {
   document.getElementById("kg").innerHTML = "Paragraph has changed.";
}