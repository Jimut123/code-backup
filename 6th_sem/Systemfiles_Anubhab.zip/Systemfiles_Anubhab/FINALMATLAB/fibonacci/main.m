%main for fibonacci
clc;
clear all;
close all;
s=fib(4);
fprintf('Fibonacci = %d',s);
