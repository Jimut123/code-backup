clc;
clear all;
close all;
n=input('\nEnter decimal number: ');
num2words(n)
%fprintf('%d in words is %s\n',n,str);