%function avg=average(a,n):Function to calculate average of all elements
%in 1-dim array a()
function avg=average(a,n)
avg=sum11(a,n)/n;
end