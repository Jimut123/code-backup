%function function to calculate tan(x)
function y=tangent(x)
y=sine(x)/cosine(x);
end