function lc=lcm1(a,b)
h=hcf1(a,b);
lc=a*b/h;
end