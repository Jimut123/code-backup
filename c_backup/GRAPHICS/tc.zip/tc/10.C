#include<stdio.h>
main()
{
	int i=1;
	i=2+2*i++;
	printf("%d",i);
	getch();
}