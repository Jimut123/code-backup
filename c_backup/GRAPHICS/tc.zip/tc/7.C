#define prod(a,b) a*b
main()
{
	int x=3,y=4;
	printf("\n %d",prod(x+2,y-1));
	getch();
}